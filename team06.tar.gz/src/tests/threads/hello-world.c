#include <stdio.h>
#include "tests/threads/tests.h"

void
test_hello_world (void) 
{
    msg("hello, world!");
}
