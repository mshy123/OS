#ifndef VM_FRAME_H
#define VM_FRAME_H

#include "threads/thread.h"
#include <list.h>

struct list frame_table;

struct frame_table_entry {
    void *frame;
    void *page;
    
    struct thread *own_thread;
    struct list_elem elem;
};

void frame_table_init (void);
void add_frame_table (void *upage, void *kpage);
void del_frame_table (void *frame);
