#include "threads/malloc.h"
#include "vm/frame.h"

void frame_table_init (void) {
    list_init(&frame_table);
}

void add_frame_table (void *upage, void *kpage) {
    struct frame_table_entry *fte = malloc(sizeof(struct frame_entry));
    fte->frame = kpage;
    fte->page = upage;
    fte->own_thread = thread_current();
    list_push_back(&frame_table, &fte->elem);
}

void frame_free () {
    struct thread *c_t = thread_current();
    struct frame_entry *fte;
    struct list_elem *f_elem = list_begin(&frame_table);

    while(f_elem != list_end(&frame_table)) {
        fte = list_entry(f_elem, struct frame_table_entry, elem);
        if(fte->own_thread->tid == c_t->tid) {
            list_remove(fte);
        }
    }
}
